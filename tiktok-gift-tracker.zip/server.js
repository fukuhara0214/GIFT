const http = require('http');
const fs = require('fs');
const path = require('path');

// A very simple static file server for the TikTok Gift Tracker web app.
// This server is intentionally dependency‑free so it works in restricted
// environments where installing npm packages may be blocked. It serves
// files out of the `public` directory relative to this script.

const publicDir = path.join(__dirname, 'public');

// Determine the port from the environment or default to 8080
const port = process.env.PORT || 8080;

const server = http.createServer((req, res) => {
  // Resolve requested path; default to index.html
  let filePath = path.join(publicDir, req.url === '/' ? 'index.html' : req.url);

  // Normalize the path and prevent directory traversal
  filePath = path.normalize(filePath).replace(/^([\\/])*\.\.([\\/]|$)/, '');

  // Determine content type based on file extension
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.ico': 'image/x-icon',
  };
  const contentType = mimeTypes[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Not Found');
      return;
    }
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
});

server.listen(port, () => {
  console.log(`TikTok Gift Tracker server is running on http://localhost:${port}`);
});