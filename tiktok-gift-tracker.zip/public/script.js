(() => {
  // Maintain a list of monitored accounts and aggregated gift data.
  const accounts = new Set();
  const giftData = {};
  const connections = {};

  const accountInput = document.getElementById('account-input');
  const addButton = document.getElementById('add-account');
  const accountList = document.getElementById('account-list');
  const tableBody = document.querySelector('#gift-table tbody');

  // Helper to rebuild the aggregated table
  function renderTable() {
    // Clear existing rows
    tableBody.innerHTML = '';
    for (const account of Object.keys(giftData)) {
      const gifters = giftData[account];
      for (const gifter of Object.keys(gifters)) {
        const coins = gifters[gifter];
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${account}</td>
          <td>${gifter}</td>
          <td>${coins}</td>
        `;
        tableBody.appendChild(row);
      }
    }
  }

  // Update aggregated data and refresh table
  function updateGiftData(account, gifter, coins) {
    if (!giftData[account]) giftData[account] = {};
    if (!giftData[account][gifter]) giftData[account][gifter] = 0;
    giftData[account][gifter] += coins;
    renderTable();
  }

  // Attempt to start tracking gifts for a specific account
  function startTracking(account) {
    // Remove leading '@'
    const cleanAccount = account.replace(/^@+/, '');
    console.log(`Starting tracking for ${cleanAccount}`);

    // If the TikTok Live Connector library is available, use it; otherwise
    // fallback to a dummy generator that produces sample gifts.
    const connectorAvailable = typeof window.TikTokLiveConnector !== 'undefined' &&
      window.TikTokLiveConnector.TikTokLiveConnection;

    if (!connectorAvailable) {
      console.warn('TikTok Live Connector library not available; using dummy data');
      // Generate dummy gift events every few seconds
      connections[account] = setInterval(() => {
        const gifter = `ユーザー${Math.floor(Math.random() * 5) + 1}`;
        const coins = Math.floor(Math.random() * 10) + 1;
        updateGiftData(account, gifter, coins);
      }, 5000);
      return;
    }

    const { TikTokLiveConnection } = window.TikTokLiveConnector;
    const connection = new TikTokLiveConnection(cleanAccount, {
      enableExtendedGiftInfo: true,
    });
    connections[account] = connection;

    connection.connect().catch(err => {
      console.error('Failed to connect to TikTok Live stream:', err);
    });

    connection.on('gift', (eventData) => {
      const gifter = eventData.uniqueId || eventData.nickname || 'Anonymous';
      const coins = eventData.diamondCount || (eventData.gift && eventData.gift.diamondCount) || 1;
      updateGiftData(account, gifter, coins);
    });
  }

  // Stop tracking and clean up resources for a given account
  function stopTracking(account) {
    const conn = connections[account];
    if (conn) {
      if (typeof conn.disconnect === 'function') {
        conn.disconnect();
      } else {
        clearInterval(conn);
      }
      delete connections[account];
    }
    delete giftData[account];
    renderTable();
  }

  // Event handler for adding an account
  addButton.addEventListener('click', () => {
    const account = accountInput.value.trim();
    if (!account) return;
    if (accounts.has(account)) {
      alert('このアカウントはすでに監視対象になっています。');
      return;
    }
    accounts.add(account);
    // Add to UI list
    const li = document.createElement('li');
    li.textContent = account;
    const removeBtn = document.createElement('button');
    removeBtn.textContent = '削除';
    removeBtn.addEventListener('click', () => {
      accounts.delete(account);
      li.remove();
      stopTracking(account);
    });
    li.appendChild(removeBtn);
    accountList.appendChild(li);

    // Start tracking
    startTracking(account);

    // Clear input
    accountInput.value = '';
  });
})();